import java.io.*;
import java.net.*;


public class IntClient {
public int x;
public int Message;
	public void run(){
		try{
		Socket Sock = new Socket("LocalHost",600);
		//InputStreamReader ISR = new InputStreamReader(Sock.getInputStream());
		//BufferedReader BR = new BufferedReader(ISR);	
		//PrintStream PS = new PrintStream(Sock.getOutputStream());
		x = 0;
		while(5 >= x ){
		InputStreamReader ISR = new InputStreamReader(Sock.getInputStream());
		BufferedReader BR = new BufferedReader(ISR);	
		PrintStream PS = new PrintStream(Sock.getOutputStream());
		System.out.println("IM LOOPING");
		Message = Integer.parseInt(BR.readLine());
		//BR.flush();
		System.out.println(Message);
		
		x++;
		}
		}
		catch(IOException e){}		
	}
	public static void main(String[] args) throws Exception{
		IntClient c = new IntClient();
		c.run();
	}
}