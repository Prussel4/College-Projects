/* 
Paul Russell
Java II
Lab 10
*/
import java.io.*;
import java.net.*;

public class Server {
	private static PrintWriter printWriter;
	private ServerSocket server;
	
	private void Start(){
		try{
			ServerSocket SS = new ServerSocket(444); 
			Socket Sock = SS.accept();
			
		PrintStream PS = new PrintStream(Sock.getOutputStream());
		PS.println("Did it work!?!?");
		
		InputStreamReader IR = new InputStreamReader(Sock.getInputStream());
		BufferedReader BR = new BufferedReader(IR);
		
		String Message = BR.readLine();
		System.out.println(Message);
		
	}
	catch(IOException e){}
	}
	public static void main(String[] args) throws Exception{
		Server s = new Server();
		s.Start();
	}
}