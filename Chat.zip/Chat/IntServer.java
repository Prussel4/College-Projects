import java.io.*;
import java.net.*;

public class IntServer {
public int x;
public int Message;	
private ServerSocket server;
private Socket connection;	
	public void run(){
	try{
	
	ServerSocket SS = new ServerSocket(600); 
	Socket Sock = SS.accept();
	
	int[] IntArray = {1,2,3,4,5};				
  	
		x = 0;
		while(5 >= x){
		Message = IntArray[x]; 
		PrintStream PS = new PrintStream(Sock.getOutputStream());
		PS.println(Message);
		PS.flush();
		x++;		
		InputStreamReader IR = new InputStreamReader(Sock.getInputStream());
		BufferedReader BR = new BufferedReader(IR);
		String Confirm = BR.readLine();
		
		}
	}
	catch(IOException e){}
	}
	public static void main(String[] args) throws Exception{
		IntServer s = new IntServer();
		s.run();
	}
}