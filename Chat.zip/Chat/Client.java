/* 
Paul Russell
Java II
Lab 10
*/
import java.io.*;
import java.net.*;

public class Client {
	public void run() throws Exception{
		Socket S = new Socket("LocalHost",444);
		InputStreamReader ISR = new InputStreamReader(S.getInputStream());
			BufferedReader BR = new BufferedReader(ISR);	
			
			String Message = BR.readLine();
			System.out.println(Message);
			
			if (Message != null){
			PrintStream PS = new PrintStream(S.getOutputStream());
			PS.println("Message was Sent!");
			}
		}	
	

	public static void main(String[] args) throws Exception{
		Client c = new Client();
		c.run();
	}
}